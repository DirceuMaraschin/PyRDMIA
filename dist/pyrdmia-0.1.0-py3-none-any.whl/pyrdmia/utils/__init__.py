'''
init das operações complexas adicionais de RDM-IA
'''

from .RMath import *
from .QualitativeMetrics import *
from .QualitativeMetrics import *
from .QuantitativeMetrics import *
