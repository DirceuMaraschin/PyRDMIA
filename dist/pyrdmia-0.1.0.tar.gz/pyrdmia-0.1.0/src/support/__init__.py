
"""IReal type sub-package

All the stuff related to the IReal type is organized here.

"""

from .error import *
